<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\candidateController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\joincontroller;
use App\Http\Controllers\position;
use App\Http\Controllers\positionController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\votersController;
use App\Models\candidate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/
/*
Route::group(['auth:sanctum']-> get ('/user').function (Request $request)){
    return $request->user();
}
*/


Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);
Route::PUT('/edit', [UserController::class, 'edit']);
Route::delete('/delete', [AuthController::class, 'delete']);
Route::get('/getdata', [AuthController::class, 'getdata']);
Route::get('/leftjoin', [joincontroller::class, 'leftjoin']);
Route::get('/join', [joincontroller::class, 'join']);
Route::get('/users', [UserController::class, 'index']);
Route::post('/store', [DepartmentController::class, 'store']);
Route::post('/storepos', [positionController::class, 'storepos']);
Route::post('/store2', [candidateController::class, 'store2']);
Route::post('/store3', [votersController::class, 'store3']);

//Route::post('/store', [UserController::class, 'store']);
//Route::get('/index', [UserController::class, 'index']);

Route::group(['middleware'=> ['auth:sanctum']], function(){

    Route::get('/users', [UserController::class, 'index']);
    Route::post('/users', [UserController::class, 'store']);
    Route::post('/users/{id}', [UserController::class, 'edit']);
    Route::delete('/users/{id}', [UserController::class, 'destroy']);
    Route::get('/students', [StudentController::class, 'index']);
    Route::delete('/users', [UserController::class, 'delete']);

    Route::get('/voters', [joincontroller::class, 'leftjoin']);
});