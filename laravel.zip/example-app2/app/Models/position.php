<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Notifications\Notifiable;

class position extends Model
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $table = 'table_position';

    protected $fillable = ['position','max_vote'];

    public function candidates()
    {
        return $this->hasMany(Candidate::class, 'position_id');
    }
}
