<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\candidate;
use App\Models\position;
use App\Models\department;

class view extends Model
{
    use HasFactory;

    
}
