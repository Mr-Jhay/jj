<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Notifications\Notifiable;


class votes extends Model
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $table = 'table_votes';

    protected $fillable = ['voters_id', 'department_id','candidate_id','position_id'];


    public function position()
    {
        return $this->belongsTo(Position::class, 'position_id');
    }

    public function department()
    {
        return $this->belongsTo(Department::class, 'department_id');
    }

    public function candidate()
    {
        return $this->belongsTo(candidate::class, 'candidate_id');
    }

    public function user()
    {
        return $this->belongsTo(Position::class, 'user_id');
    }
}
