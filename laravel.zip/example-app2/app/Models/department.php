<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Notifications\Notifiable;

class department extends Model
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $table = 'table_department';

    protected $fillable = ['department'];

    public function candidates()
    {
        return $this->hasMany(Candidate::class, 'department_id');
    }
}
