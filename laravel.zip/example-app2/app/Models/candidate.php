<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Notifications\Notifiable;

class candidate extends Model
{
    use HasApiTokens, HasFactory, Notifiable;


    protected $table = 'table_candidates';

    protected $fillable = ['position_id', 'department_id','firstname','lastname','platform'];


    public function position()
    {
        return $this->belongsTo(Position::class, 'position_id');
    }

    public function department()
    {
        return $this->belongsTo(Department::class, 'department_id');
    }

    public function candidate()
    {
        return $this->belongsTo(candidate::class, 'candidate_id');
    }
}
