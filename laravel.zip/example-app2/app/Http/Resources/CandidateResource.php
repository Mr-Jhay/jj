<?php

// app/Http/Resources/CandidateResource.php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CandidateResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'position' => [
                'id' => $this->position->id,
                'name' => $this->position->name,
                // Add other position details if needed
            ],
            'department' => [
                'id' => $this->department->id,
                'name' => $this->department->name,
                // Add other department details if needed
            ],
            // Add other candidate details if needed
        ];
    }
}
