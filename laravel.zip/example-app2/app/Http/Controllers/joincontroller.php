<?php

namespace App\Http\Controllers;
use App\Models\candidate;
use App\Models\position;
use App\Models\department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\DB as FacadesDB;

class joincontroller extends Controller
{
    public function leftjoin()
    {
        $items = DB::table('table_candidates')
    ->leftjoin('table_position', 'table_candidates.position_id', '=', 'table_position.id')
    ->leftjoin('table_department', 'table_candidates.department_id', '=', 'table_department.id')
    ->select('table_candidates.*', 'table_position.position as position_name', 'table_department.department as department_name')
    ->get();

    return $items;

       

        
    }



    public function join()
    {
        $items = DB::table('table_votes')
        ->join('table_candidates', 'table_votes.candidate_id', '=', 'table_candidates.id')
        ->join('users', 'table_votes.voters_id', '=', 'users.id')
        ->join('table_position', 'table_candidates.position_id', '=', 'table_position.id')
        ->join('table_department', 'table_candidates.department_id', '=', 'table_department.id')
        ->select(
            'table_votes.id as vote_id',
            'users.name as voter_name',
            'table_department.department as department_name',
            'table_position.position as position_name',
            'table_candidates.firstname as candidate_name'
        )
        ->get();

      //  $token = $items->createToken('Personal Access Token')->plainTextToken;
       // $response = ['db' => $items, 'token' => $token];
      //  $response = ['message'=>'success'];
       // return response()->json($response, 200);

    return $items;

       

        
    }

}
