<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller {
    
    public function register(Request $req){

        $rules = [
            'name' => 'required|string',
            'email' => 'required|string|email|unique:users',
            'age' => 'required|integer',
            'account_type' => 'required|string',
            'password' => 'required|string|min:6'
        ];

        $validator = Validator::make($req->all(), $rules);
        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $user = User::create([
            'name' => $req->name,
            'email' => $req->email,
            'age' => $req->age,
            'account_type' => $req->account_type,
            'password' => Hash::make($req->password)

            
        ]);
        
        $token = $user->createToken('Personal Access Token')->plainTextToken;
        $response = ['user' => $user, 'token' => $token];
        $response = ['message'=>'success'];
        return response()->json($response, 200);
    }
       
    
    public function login(Request $req){
        
        $rules = [
            'email' => 'required|email',
            'password' => 'required|string'
        ];

        $req->validate($rules);
        $user = User::Where('email', $req->email) -> first();
        if($user && Hash::check($req->password, $user->password)) {
            $token = $user->createToken('Personal Access Token')->plainTextToken;
            $response=['user'=>$user, 'token'=>$token];
            return response()->json($response, 200);
        }

        $response = ['message'=>'Incorrect email or password'];
        return response()->json($response, 400);

        
    }   

    public function edit(request $request)
    {
        $items=User::findorfail($request->id);

        $items-> name = $request->name;
        $items-> email = $request->email;
        $items->age = $request->age;
        $items->account_type = $request->account_type;
      


        $items->update();

      //  return response()->json('updated successfull');

        $token = $items->createToken('Personal Access Token')->plainTextToken;
        $response = ['user' => $items, 'token' => $token];
        $response = ['message'=>'success'];
        return response()->json($response, 200);
        

    }
    


    public function delete(request $request)
    {
       
       $items=User::findorfail($request->id)->delete();
       return response()->json('deleted successfull');
    }

    public function getdata()
    {
       
       $items=User::all();

       //return response()->json($items);
       $token = $items->createToken('Personal Access Token')->plainTextToken;
       $response = ['user' => $items, 'token' => $token];
       $response = ['message'=>'success'];
       return response()->json($response, 200);
       
    }

}