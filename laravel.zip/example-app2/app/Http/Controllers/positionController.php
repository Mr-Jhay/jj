<?php

namespace App\Http\Controllers;
use App\Models\position;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Eloquent\Model;

class positionController extends Controller
{
    public function storepos(Request $request)
    {
        // Validate the request data if necessary

        position::create([
            'position' => $request->input('position'),
            'max_vote' => $request->input('max_vote')
            // Add other columns as needed
        ]);
        return response()->json('updated successfull');

        // Redirect or respond as needed
    }


    public function editpos(request $request)
    {
        $items=position::findorfail($request->id);

        $items-> position = $request->position;
        $items-> max_vote = $request->max_vote;
       
      


        $items->update();

        return response()->json('updated successfull');
        

    }
    public function deletepos(request $request)
    {
       
       $items=position::findorfail($request->id);
       $items->delete();
       return response()->json('deleted successfull');
    }

    public function getdatapos()
    {
       
       $items=position::all();

       return response()->json($items);
    }

}
