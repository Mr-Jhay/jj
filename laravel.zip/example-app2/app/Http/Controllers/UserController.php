<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\UserCollection;
use App\Http\Resources\UserCollection as ResourcesUserCollection;
use GuzzleHttp\Psr7\Response;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;


class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return response([
            'users' => User::select('id', 'name', 'email')->get()
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $req)
    {
        $rules = [
            'name' => 'required|string',
            'email' => 'required|string|email|unique:users',
            'age' => 'required|integer',
            'account_type' => 'required|string',
            'password' => 'required|string|min:6'
        ];

        $validator = Validator::make($req->all(), $rules);
        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $user = User::create([
            'name' => $req->name,
            'email' => $req->email,
            'age' => $req->age,
            'account_type' => $req->account_type,
            'password' => Hash::make($req->password)

            
        ]);
        
        $token = $user->createToken('Personal Access Token')->plainTextToken;
        $response = ['user' => $user, 'token' => $token];
        $response = ['message'=>'success'];
        return response()->json($response, 200);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(request $request)
    {
        $items=User::findorfail($request->id);

        $items-> name = $request->name;
       $items-> email = $request->email;
       $items->age = $request->age;
       $items->account_type = $request->account_type;
      


        $items->update();

       $token = $items->createToken('Personal Access Token')->plainTextToken;
     $response = ['user' => $items, 'token' => $token];
       $response = ['message'=>'updated'];
       return response()->json($response, 200);

      //return response()->json(['message' => 'Item updated successfully']);
        

        


    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
       $record = User::find($id);

       if($record){
            $record->delete();
            return response([
                'response' => 'success'
            ], 200);
       }

        return response([
            'response' => 'error'
        ], 403);

    }
}
