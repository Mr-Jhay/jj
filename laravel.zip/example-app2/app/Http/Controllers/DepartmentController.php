<?php

namespace App\Http\Controllers;
use App\Models\department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Eloquent\Model;



class DepartmentController extends Controller
{
    public function store(Request $request)
    {
        // Validate the request data if necessary

        department::create([
            'department' => $request->input('department'),
           
            // Add other columns as needed
        ]);

        // Redirect or respond as needed
    }
}
