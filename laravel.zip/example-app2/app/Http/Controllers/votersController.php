<?php

namespace App\Http\Controllers;

use App\Models\candidate;
use App\Models\position;
use App\Models\department;
use App\Models\votes;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;


class votersController extends Controller
{
    public function store3(Request $request)
    {
        // Assuming you have positions and departments already created in the database
    
       
    
        votes::create([
            //'position_id' => $request->id,
            'voters_id' => $request->input('voters_id'),
            'department_id' => $request->input('department_id'),
            'candidate_id'=> $request->input('candidate_id'),
            'position_id' => $request->input('position_id'),
        ]);
        return response()->json('updated successfull');
    
        // Redirect or respond as needed
    }


    
}
