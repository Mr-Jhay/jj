<?php


namespace App\Http\Controllers;
use App\Models\candidate;
use App\Models\position;
use App\Models\department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class candidateController extends Controller
{
    public function store2(Request $request)
    {
        // Assuming you have positions and departments already created in the database
    
       
    
        $items=Candidate::create([
            //'position_id' => $request->id,
            'position_id' => $request->input('position_id'),
            'department_id' => $request->input('department_id'),
            'firstname'=> $request->input('firstname'),
            'lastname' => $request->input('lastname'),
            'platform' => $request->input('platform'),
        ]);
        //return response()->json('updated successfull');

        $token = $items->createToken('Personal Access Token')->plainTextToken;
        $response = ['candidate' => $items, 'token' => $token];
        $response = ['message'=>'success'];
        return response()->json($response, 200);
    
        // Redirect or respond as needed
    }

    public function editcan(request $request)
    {
        $items=candidate::findorfail($request->id);

        $items-> firstname = $request->firstname;
        $items-> lastname = $request->lastname;
        $items-> platform = $request->platform;
       
      


        $items->update();

        $token = $items->createToken('Personal Access Token')->plainTextToken;
        $response = ['canidate' => $items, 'token' => $token];
        $response = ['message'=>'success'];
        return response()->json($response, 200);
        

    }
    public function deletecan(request $request)
    {
       
       $items=candidate::findorfail($request->id);
       $items->delete();
      // return response()->json('deleted successfull');
       $token = $items->createToken('Personal Access Token')->plainTextToken;
       $response = ['candidate' => $items, 'token' => $token];
       $response = ['message'=>'success'];
       return response()->json($response, 200);
    }


    public function getdata()
    {
       
       $items=candidate::all();

       return response()->json($items);
    }

}
