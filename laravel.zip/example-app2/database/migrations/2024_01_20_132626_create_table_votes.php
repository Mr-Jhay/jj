<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('table_votes', function (Blueprint $table) {
            $table->unsignedBigInteger('voters_id')->change();
            $table->unsignedBigInteger('department_id')->change();
            $table->unsignedBigInteger('candidate_id')->change();
            $table->unsignedBigInteger('position_id')->change();

            $table->foreign('voters_id')->references('id')->on('users');
            $table->foreign('department_id')->references('id')->on('table_department');
            $table->foreign('candidate_id')->references('id')->on('table_candidates');
            $table->foreign('position_id')->references('id')->on('table_position');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        
    }
};
